package exceptions;

public class CapitaoNaoInformadoException extends RuntimeException {
    public CapitaoNaoInformadoException(String msg){ super(msg); }
}
