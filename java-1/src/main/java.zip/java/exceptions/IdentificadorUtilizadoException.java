package exceptions;

public class IdentificadorUtilizadoException extends RuntimeException {
    public IdentificadorUtilizadoException(String msg){
        super(msg);
    }
}
