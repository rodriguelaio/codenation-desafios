package exceptions;

public class JogadorNaoEncontradoException extends RuntimeException {
    public JogadorNaoEncontradoException(String msg){ super(msg); }
}
