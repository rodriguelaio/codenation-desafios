package repositories;

import domain.Jogador;
import domain.Time;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Repository {

    private List<Time> times = new ArrayList<>();
    private List<Jogador> jogadores = new ArrayList<>();
    private Map<Long, String> registroIdsTimes = new HashMap<>();
    private Map<Long, String> registroIdsJogadores = new HashMap<Long, String>();
    //    private Map<Long, Map<Long, String>> registroTimeXJogadores = new HashMap<>();
    private Map<Long, Long> registroJogadoresXTimes = new HashMap<>();
    private Map<Long, Long> registroTimesXCapitaes = new HashMap<>();

    protected boolean validaIdInexistente(Class instanciaGenerica, Long id){
        gravaLog();
        if(instanciaGenerica == Time.class) return registroIdsTimes.get(id) == null;
        return registroIdsJogadores.get(id) == null;
    }

    protected void armazenaTime(Time time){
        times.add(time);
        registroIdsTimes.put(time.getId(), time.getNome());
    }

    protected void armazenaJogador(Jogador jogador){
        jogadores.add(jogador);
        registroIdsJogadores.put(jogador.getId(), jogador.getNome());
        registroJogadoresXTimes.put(jogador.getId(), jogador.getIdTime());
    }

    protected void definirCapitao(Long idJogador){
        registroTimesXCapitaes.put(registroJogadoresXTimes.get(idJogador), idJogador);
    }

    protected Long buscarCapitaoDoTime(Long idTime){
        return registroTimesXCapitaes.get(idTime);
    }

    protected String buscarNomeJogador(Long idJogador){
        return registroIdsJogadores.get(idJogador);
    }

    protected String buscarNomeTime(Long idTime){
        return registroIdsTimes.get(idTime);
    }

    protected List<Long> buscarJogadoresDoTime(Long idTime){
        List<Long> jogadoresXTime = new ArrayList<>();
        for (Map.Entry<Long, Long> entry : registroJogadoresXTimes.entrySet()) {
            if (entry.getValue() == idTime) {
                jogadoresXTime.add(entry.getKey());
//                System.out.println(entry.getKey());
            }
        }
        Collections.sort(jogadoresXTime);
        return jogadoresXTime;
    }

    protected Long buscarMelhorJogadorDoTime(Long idTime){
        return buscarMaiorValorJogador(1, idTime);
    }

    protected Long buscarJogadorMaisVelho(Long idTime){
        return buscarMaiorValorJogador(2, idTime);
    }

    protected Long buscarJogadorMaiorSalario(Long idTime){
        return buscarMaiorValorJogador(3, idTime);
    }

    protected List<Long> buscarTopJogadores(Integer top){
        AtomicInteger count = new AtomicInteger();
        List<Long> topJogadores = new ArrayList<>();
        Collections.sort(jogadores, new Comparator<Jogador>() {
            public int compare(Jogador j1, Jogador j2) {
                return j2.getNivelHabilidade().compareTo(j1.getNivelHabilidade());
            }
        });
        jogadores.forEach(jogador -> {
            if (count.getAndIncrement() < top) {
                topJogadores.add(jogador.getId());
            } else {
                if (topJogadores.get(top - 1) > jogador.getId() && jogador.getNivelHabilidade().equals(jogadores.get(count.get() - 2).getNivelHabilidade())) {
                    topJogadores.set(top - 1, jogador.getId());
                }
            }
        });
        return topJogadores;
    }

    private Long buscarMaiorValorJogador(int opcao, Long idTime){
        Long jogadorVencedorComparacao = null;
        int maiorValor = 0;
        int valorComparativo;
        List<Long> jogadoresXTime = buscarJogadoresDoTime(idTime);
        for (domain.Jogador jogador : jogadores) {
            if(jogadoresXTime.indexOf(jogador.getId()) >= 0 && maiorValor < (valorComparativo = retornaAtributoDeJogador(opcao, jogador))){
                maiorValor = valorComparativo;
                jogadorVencedorComparacao = jogador.getId();
            }
        }
        return jogadorVencedorComparacao;
    }

    private int retornaAtributoDeJogador(int opcao, Jogador jogador){
        if(opcao == 1) return jogador.getNivelHabilidade();
        if(opcao == 2) return (int) ChronoUnit.YEARS.between(jogador.getDataNascimento(), LocalDate.now());
        /*if(opcao == 3)*/ return jogador.getSalario().intValue();
    }

    protected List<Long> buscarTimes(){
        List<Long> times = new ArrayList<>();
        this.times.forEach(time -> times.add(time.getId()));
        Collections.sort(times);
        return times;
    }

    protected BigDecimal buscarSalarioDoJogador(Long idJogador){
        Jogador jogadorEncontrado = jogadores.stream().filter(jogador -> idJogador.equals(jogador.getId())).findAny().orElse(null);
        return jogadorEncontrado.getSalario();
    }

    protected String buscarCorCamisaTimeDeFora(Long timeDaCasa, Long timeDeFora){
        Time timeDaCasaEcontrado = times.stream().filter(time -> timeDaCasa.equals(time.getId())).findAny().orElse(null);
        Time timeDeForaEncontrado = times.stream().filter(time -> timeDeFora.equals(time.getId())).findAny().orElse(null);
        return timeDaCasaEcontrado.getCorUniformePrincipal().equals(timeDeForaEncontrado.getCorUniformePrincipal()) ? timeDeForaEncontrado.getCorUniformeSecundario() : timeDeForaEncontrado.getCorUniformePrincipal();
    }

    private void gravaLog() {
        FileWriter arq = null;
        try {
            arq = new FileWriter("/Users/rodrigoprates/log.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
        PrintWriter gravarArq = new PrintWriter(arq);

        gravarArq.printf("+--Jogadores--+\n");
//        jogadores.forEach(jogador -> gravarArq.printf("id: " + jogador.getId() + "\n" +
//                "nome: " + jogador.getNome() + "\n" +
//                "time: " + jogador.getIdTime() + "\n" +
//                "salario: " + jogador.getSalario() + "\n" +
//                "nascimento: " + jogador.getDataNascimento() + "\n" +
//                "habilidade: " + jogador.getNivelHabilidade() + "\n" +
//                "\n\n"));

        jogadores.forEach(jogador -> gravarArq.printf("dataLoader.incluirJogador(" + jogador.getId() + "L," + "\n" +
        "" + jogador.getIdTime() + "L," + "\n" +
        '"' + jogador.getNome() + '"' + ',' + "\n" +
        "LocalDate.parse(" + '"' + jogador.getDataNascimento() + '"' + ",DateTimeFormatter.ofPattern(" + '"' + "yyyy-MM-dd" + '"' + "))," + "\n" +
        "" + jogador.getNivelHabilidade() + "," + "\n" +
        "new BigDecimal(" + jogador.getSalario() + "));" + "\n\n"));

        gravarArq.printf("+-------------+\n");

        gravarArq.printf("+--Times--+\n");

        times.forEach(time -> gravarArq.printf("id: " + time.getId() + "\n" +
                "nome: " + time.getNome() + "\n" +
                "data criacao: " + time.getDataCriacao() + "\n" +
                "uniforme principal: " + time.getCorUniformePrincipal() + "\n" +
                "uniforme secundario: " + time.getCorUniformeSecundario() + "\n" +
                "\n\n"));
        gravarArq.printf("+-------------+\n");

        try {
            arq.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
